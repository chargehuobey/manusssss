/**
 * apps/octobrowser/test/identity-retirement.test.ts
 *
 * Replaces the old fingerprint-runtime.test.ts, which asserted that a stub
 * returns null and therefore proved nothing. These are static guards on the
 * seams that would have to be reopened for synthetic identity overrides to
 * come back: the preload config, the profile resolution, and the header hook.
 *
 * If one of these starts failing, someone is re-introducing fingerprint
 * spoofing -- read apps/octobrowser/src/main/runtime.ts:195-206 first.
 */
import { describe, expect, it } from 'vitest';
import { existsSync, readFileSync } from 'node:fs';
import * as path from 'node:path';

const root = path.resolve(__dirname, '..', '..', '..');
const read = (...p: string[]) => readFileSync(path.join(root, ...p), 'utf8');

describe('synthetic identity stays retired', () => {
  it('the retired stub module stays deleted', () => {
    expect(existsSync(path.join(root, 'apps/octobrowser/src/main/fingerprint-runtime.ts'))).toBe(false);
  });

  it('the preload receives no identity overrides', () => {
    expect(read('apps/octobrowser/src/main/window.ts')).toContain('fp: null,');
  });

  it('the stored fingerprint is force-disabled at every resolution site', () => {
    const rt = read('apps/octobrowser/src/main/runtime.ts');
    expect(rt.match(/enabled: false \}, undefined, this\.lang\)/g)?.length).toBeGreaterThanOrEqual(2);
    expect(rt).toContain("'fingerprint.retired'");
  });

  it('no UA or language header hook is wired back into the session', () => {
    expect(read('packages/shell/src/session-privacy.ts'))
      .toMatch(/updateIdentity\([^)]*\): void \{\s*\}/);
  });
});
